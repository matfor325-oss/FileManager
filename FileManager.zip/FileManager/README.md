# مدير الملفات (FileManager)
مشروع Android (Kotlin + Jetpack Compose).

## طريقة 1: Android Studio (على الكمبيوتر)
1. فك ضغط المشروع، ثم File > Open واختر مجلد FileManager.
2. انتظر انتهاء المزامنة (Sync).
3. Build > Build APK(s)  → ستجد الملف في app/build/outputs/apk/debug/app-debug.apk

## طريقة 2: GitHub (بدون برامج)
1. أنشئ مستودعًا جديدًا في github.com وارفع كل محتويات المجلد (بما فيها مجلد .github).
2. من تبويب Actions شغّل "Build APK".
3. بعد دقائق حمّل app-debug.apk من قسم Artifacts.
