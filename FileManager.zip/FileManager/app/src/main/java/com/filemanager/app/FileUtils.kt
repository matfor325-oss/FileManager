package com.filemanager.app

import android.webkit.MimeTypeMap
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** ترتيب الأحرف: رموز ثم أرقام ثم إنجليزي (a-z) ثم عربي */
fun charRank(c: Char): Int = when {
    c.isDigit() -> 1
    c in 'a'..'z' || c in 'A'..'Z' -> 2
    c in '\u0600'..'\u06FF' || c in '\u0750'..'\u077F' -> 3
    c.isLetter() -> 4
    else -> 0
}

fun compareNames(x: String, y: String): Int {
    var i = 0
    var j = 0
    while (i < x.length && j < y.length) {
        val cx = x[i]
        val cy = y[j]
        if (cx in '0'..'9' && cy in '0'..'9') {
            var ni = i
            while (ni < x.length && x[ni] in '0'..'9') ni++
            var nj = j
            while (nj < y.length && y[nj] in '0'..'9') nj++
            val a = x.substring(i, ni).trimStart('0')
            val b = y.substring(j, nj).trimStart('0')
            if (a.length != b.length) return a.length - b.length
            val c = a.compareTo(b)
            if (c != 0) return c
            i = ni
            j = nj
        } else {
            val rx = charRank(cx)
            val ry = charRank(cy)
            if (rx != ry) return rx - ry
            val lx = cx.lowercaseChar()
            val ly = cy.lowercaseChar()
            if (lx != ly) return lx.compareTo(ly)
            i++
            j++
        }
    }
    return (x.length - i) - (y.length - j)
}

/** المجلدات أولاً ثم الملفات. byDate=true: الأحدث أولاً، وإلا حسب الاسم */
fun sortItems(list: List<File>, byDate: Boolean): List<File> {
    val dirs = list.filter { it.isDirectory }
    val files = list.filter { !it.isDirectory }
    val cmp: Comparator<File> =
        if (byDate) Comparator { a, b -> b.lastModified().compareTo(a.lastModified()) }
        else Comparator { a, b -> compareNames(a.name, b.name) }
    return dirs.sortedWith(cmp) + files.sortedWith(cmp)
}

fun uniqueFile(dir: File, name: String): File {
    var f = File(dir, name)
    if (!f.exists()) return f
    val hasDot = name.contains('.') && !name.startsWith(".")
    val base = if (hasDot) name.substringBeforeLast('.') else name
    val ext = if (hasDot) "." + name.substringAfterLast('.') else ""
    var i = 1
    while (f.exists()) {
        f = File(dir, "$base ($i)$ext")
        i++
    }
    return f
}

fun zipFiles(files: List<File>, out: File) {
    ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { zos ->
        fun add(f: File, base: String) {
            val name = if (base.isEmpty()) f.name else base + "/" + f.name
            if (f.isDirectory) {
                zos.putNextEntry(ZipEntry("$name/"))
                zos.closeEntry()
                f.listFiles()?.forEach { add(it, name) }
            } else {
                zos.putNextEntry(ZipEntry(name))
                FileInputStream(f).use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
        files.forEach { add(it, "") }
    }
}

fun unzip(zip: File, destDir: File) {
    destDir.mkdirs()
    val destPath = destDir.canonicalPath
    ZipInputStream(BufferedInputStream(FileInputStream(zip))).use { zis ->
        var e = zis.nextEntry
        while (e != null) {
            val f = File(destDir, e.name)
            if (!f.canonicalPath.startsWith(destPath + File.separator)) {
                throw SecurityException("مسار غير آمن داخل الملف المضغوط")
            }
            if (e.isDirectory) {
                f.mkdirs()
            } else {
                f.parentFile?.mkdirs()
                FileOutputStream(f).use { zis.copyTo(it) }
            }
            zis.closeEntry()
            e = zis.nextEntry
        }
    }
}

fun extOf(f: File): String = f.extension.lowercase()

fun mimeOf(f: File): String =
    MimeTypeMap.getSingleton().getMimeTypeFromExtension(extOf(f)) ?: "*/*"

val TEXT_EXT = setOf(
    "txt", "json", "js", "ts", "lua", "xml", "md", "html", "htm", "css", "properties",
    "lang", "mcfunction", "ini", "cfg", "conf", "log", "csv", "yml", "yaml", "java",
    "kt", "py", "mcmeta", "toml", "sh", "bat", "gradle", "smali", "json5", "material",
    "fragment", "vertex", "geometry", "entity", "item", "block"
)
val ARCHIVE_EXT = setOf("zip", "mcpack", "mcaddon", "mcworld")

fun isTextFile(f: File): Boolean =
    f.isFile && (extOf(f) in TEXT_EXT || mimeOf(f).startsWith("text/"))

fun isArchive(f: File): Boolean = f.isFile && extOf(f) in ARCHIVE_EXT

fun iconFor(f: File): String {
    if (f.isDirectory) return "📁"
    return when (extOf(f)) {
        "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic" -> "🖼️"
        "mp3", "m4a", "wav", "ogg", "flac", "aac", "opus" -> "🎵"
        "mp4", "mkv", "avi", "mov", "webm", "3gp" -> "🎬"
        "zip", "rar", "7z", "mcpack", "mcaddon", "mcworld", "tar", "gz" -> "📦"
        "apk" -> "🤖"
        "pdf" -> "📕"
        else -> if (isTextFile(f)) "📝" else "📄"
    }
}

fun formatSize(b: Long): String = when {
    b < 1024 -> "$b B"
    b < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
    b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
    else -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
}

fun formatDate(t: Long): String =
    SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.US).format(Date(t))
