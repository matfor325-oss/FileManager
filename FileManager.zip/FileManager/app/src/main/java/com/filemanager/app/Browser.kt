package com.filemanager.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Environment
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class Mode { MAIN, DOWNLOADS }

fun toast(ctx: Context, msg: String) {
    Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun BrowserScreen(
    mode: Mode,
    clipboard: SnapshotStateList<File>,
    onEdit: (File) -> Unit,
    onExit: () -> Unit
) {
    val ctx = LocalContext.current
    val root = remember(mode) {
        if (mode == Mode.DOWNLOADS)
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        else Environment.getExternalStorageDirectory()
    }
    var dir by remember(mode) { mutableStateOf(root) }
    var refresh by remember { mutableIntStateOf(0) }
    val selected = remember { mutableStateListOf<File>() }
    var openTarget by remember { mutableStateOf<File?>(null) }
    var showMore by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<File?>(null) }
    var detailsTarget by remember { mutableStateOf<File?>(null) }
    var extMenu by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val listing = remember(dir, refresh, mode) {
        sortItems(dir.listFiles()?.toList() ?: emptyList(), mode == Mode.DOWNLOADS)
    }

    fun navigate(d: File) {
        selected.clear()
        dir = d
    }

    fun runWork(work: () -> String?) {
        scope.launch {
            busy = true
            val msg = withContext(Dispatchers.IO) {
                try {
                    work()
                } catch (e: Exception) {
                    "فشلت العملية: ${e.message}"
                }
            }
            busy = false
            refresh++
            if (msg != null) toast(ctx, msg)
        }
    }

    fun doPaste() {
        val src = clipboard.toList()
        val target = dir
        selected.clear()
        runWork {
            var n = 0
            for (s in src) {
                if (!s.exists()) continue
                val dest = uniqueFile(target, s.name)
                if (s.isDirectory) {
                    val sp = s.canonicalPath
                    val dp = dest.canonicalPath
                    if (dp == sp || dp.startsWith(sp + File.separator)) continue
                    s.copyRecursively(dest)
                } else {
                    s.copyTo(dest)
                }
                n++
            }
            "تم لصق $n عنصر"
        }
    }

    fun addExtension(ext: String) {
        val files = selected.toList()
        selected.clear()
        runWork {
            var n = 0
            for (f in files) {
                if (f.isFile && !f.name.endsWith(ext, ignoreCase = true)) {
                    val parent = f.parentFile ?: continue
                    val target = uniqueFile(parent, f.name + ext)
                    if (f.renameTo(target)) n++
                }
            }
            "تمت إضافة $ext إلى $n ملف"
        }
    }

    BackHandler {
        val parent = dir.parentFile
        when {
            selected.isNotEmpty() -> selected.clear()
            dir.path != root.path && parent != null -> navigate(parent)
            else -> onExit()
        }
    }

    Scaffold(
        topBar = {
            Surface(tonalElevation = 3.dp) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (selected.isNotEmpty()) {
                        TextButton(onClick = { selected.clear() }) { Text("✕") }
                        Text("${selected.size} محدد", Modifier.weight(1f))
                        TextButton(onClick = {
                            selected.clear()
                            selected.addAll(listing)
                        }) { Text("تحديد الكل") }
                        Box {
                            TextButton(onClick = { extMenu = true }) { Text("الامتداد ▾") }
                            DropdownMenu(expanded = extMenu, onDismissRequest = { extMenu = false }) {
                                listOf(".mcpack", ".mcaddon").forEach { ext ->
                                    DropdownMenuItem(
                                        text = { Text(ext) },
                                        onClick = {
                                            extMenu = false
                                            addExtension(ext)
                                        }
                                    )
                                }
                            }
                        }
                    } else {
                        TextButton(onClick = {
                            val parent = dir.parentFile
                            if (dir.path != root.path && parent != null) navigate(parent) else onExit()
                        }) { Text("→") }
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (mode == Mode.DOWNLOADS) "التحميلات" else "التخزين الرئيسي",
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                dir.path,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        },
        bottomBar = {
            if (selected.isNotEmpty()) {
                Surface(tonalElevation = 3.dp) {
                    Row(Modifier.fillMaxWidth().padding(4.dp)) {
                        BarButton("نسخ") {
                            clipboard.clear()
                            clipboard.addAll(selected)
                            toast(ctx, "تم نسخ ${clipboard.size} عنصر")
                            selected.clear()
                        }
                        BarButton("لصق", enabled = clipboard.isNotEmpty()) { doPaste() }
                        BarButton("فتح باستخدام") {
                            val f = selected.singleOrNull()
                            if (f == null) {
                                toast(ctx, "اختر عنصرًا واحدًا")
                            } else if (f.isDirectory) {
                                navigate(f)
                            } else {
                                openTarget = f
                                selected.clear()
                            }
                        }
                        BarButton("حذف") { showDelete = true }
                        BarButton("المزيد") { showMore = true }
                    }
                }
            } else if (clipboard.isNotEmpty()) {
                Surface(tonalElevation = 3.dp) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${clipboard.size} عنصر جاهز للصق", Modifier.weight(1f))
                        TextButton(onClick = { doPaste() }) { Text("لصق هنا") }
                        TextButton(onClick = { clipboard.clear() }) { Text("إلغاء") }
                    }
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            LazyColumn(Modifier.fillMaxSize()) {
                if (listing.isEmpty()) {
                    item { Text("المجلد فارغ", Modifier.padding(24.dp)) }
                }
                items(listing, key = { it.path }) { f ->
                    FileRow(
                        f = f,
                        selected = f in selected,
                        onClick = {
                            if (selected.isNotEmpty()) {
                                if (f in selected) selected.remove(f) else selected.add(f)
                            } else if (f.isDirectory) {
                                navigate(f)
                            } else {
                                openTarget = f
                            }
                        },
                        onLong = {
                            if (f in selected) selected.remove(f) else selected.add(f)
                        }
                    )
                }
            }
            if (busy) CircularProgressIndicator(Modifier.align(Alignment.Center))
        }
    }

    // ---------- نوافذ الحوار ----------

    openTarget?.let { f ->
        OpenWithDialog(
            file = f,
            onDismiss = { openTarget = null },
            onEdit = { file ->
                if (file.length() > 2L * 1024 * 1024) toast(ctx, "الملف كبير جدًا للتعديل (أكثر من 2MB)")
                else onEdit(file)
            }
        )
    }

    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("حذف") },
            text = { Text("هل تريد حذف ${selected.size} عنصر نهائيًا؟") },
            confirmButton = {
                TextButton(onClick = {
                    val files = selected.toList()
                    selected.clear()
                    showDelete = false
                    runWork {
                        files.forEach { it.deleteRecursively() }
                        "تم الحذف"
                    }
                }) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { showDelete = false }) { Text("إلغاء") } }
        )
    }

    if (showMore) {
        AlertDialog(
            onDismissRequest = { showMore = false },
            title = { Text("المزيد") },
            text = {
                Column {
                    MoreItem("مشاركة") {
                        showMore = false
                        val files = selected.filter { it.isFile }
                        if (files.isEmpty()) {
                            toast(ctx, "لا يمكن مشاركة المجلدات")
                        } else {
                            val uris = files.map {
                                FileProvider.getUriForFile(ctx, ctx.packageName + ".provider", it)
                            }
                            val i = if (uris.size == 1) {
                                Intent(Intent.ACTION_SEND).apply {
                                    type = "*/*"
                                    putExtra(Intent.EXTRA_STREAM, uris[0])
                                }
                            } else {
                                Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                                    type = "*/*"
                                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
                                }
                            }
                            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            ctx.startActivity(Intent.createChooser(i, "مشاركة"))
                        }
                    }
                    MoreItem("ضغط (zip)") {
                        showMore = false
                        val files = selected.toList()
                        val out = uniqueFile(
                            dir,
                            if (files.size == 1) files[0].name + ".zip" else "archive.zip"
                        )
                        selected.clear()
                        runWork {
                            zipFiles(files, out)
                            "تم إنشاء ${out.name}"
                        }
                    }
                    MoreItem("فك الضغط") {
                        showMore = false
                        val f = selected.singleOrNull()
                        if (f == null || !isArchive(f)) {
                            toast(ctx, "اختر ملف zip واحدًا")
                        } else {
                            val d = uniqueFile(dir, f.nameWithoutExtension)
                            selected.clear()
                            runWork {
                                unzip(f, d)
                                "تم فك الضغط إلى ${d.name}"
                            }
                        }
                    }
                    MoreItem("إعادة تسمية") {
                        showMore = false
                        val f = selected.singleOrNull()
                        if (f == null) toast(ctx, "اختر عنصرًا واحدًا")
                        else {
                            renameTarget = f
                            selected.clear()
                        }
                    }
                    MoreItem("تفاصيل") {
                        showMore = false
                        val f = selected.singleOrNull()
                        if (f == null) toast(ctx, "اختر عنصرًا واحدًا")
                        else {
                            detailsTarget = f
                            selected.clear()
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showMore = false }) { Text("إغلاق") } }
        )
    }

    renameTarget?.let { target ->
        var newName by remember(target) { mutableStateOf(target.name) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("إعادة تسمية") },
            text = {
                OutlinedTextField(value = newName, onValueChange = { newName = it }, singleLine = true)
            },
            confirmButton = {
                TextButton(onClick = {
                    val n = newName.trim()
                    val t = File(target.parentFile, n)
                    if (n.isEmpty() || n.contains('/')) {
                        toast(ctx, "اسم غير صالح")
                    } else if (t.exists()) {
                        toast(ctx, "الاسم موجود مسبقًا")
                    } else {
                        toast(ctx, if (target.renameTo(t)) "تمت إعادة التسمية" else "فشلت إعادة التسمية")
                        refresh++
                    }
                    renameTarget = null
                }) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("إلغاء") } }
        )
    }

    detailsTarget?.let { t ->
        AlertDialog(
            onDismissRequest = { detailsTarget = null },
            title = { Text(t.name) },
            text = {
                Text(
                    "المسار: ${t.path}\n" +
                        (if (t.isDirectory) "النوع: مجلد\nالعناصر: ${t.list()?.size ?: 0}\n"
                        else "الحجم: ${formatSize(t.length())}\n") +
                        "آخر تعديل: ${formatDate(t.lastModified())}"
                )
            },
            confirmButton = { TextButton(onClick = { detailsTarget = null }) { Text("إغلاق") } }
        )
    }
}

@Composable
fun RowScope.BarButton(label: String, enabled: Boolean = true, onClick: () -> Unit) {
    TextButton(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.weight(1f),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 2.dp, vertical = 8.dp)
    ) {
        Text(label, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 2)
    }
}

@Composable
fun MoreItem(label: String, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Text(label, Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileRow(f: File, selected: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val bg = if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
    val info = remember(f.path, f.lastModified()) {
        val extra = if (f.isDirectory) "${f.list()?.size ?: 0} عنصر" else formatSize(f.length())
        formatDate(f.lastModified()) + "  •  " + extra
    }
    Row(
        Modifier
            .fillMaxWidth()
            .background(bg)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(iconFor(f), fontSize = 28.sp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(
                info,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (selected) Text("✔", fontSize = 20.sp)
    }
}

@Composable
fun OpenWithDialog(file: File, onDismiss: () -> Unit, onEdit: (File) -> Unit) {
    val ctx = LocalContext.current
    val pm = ctx.packageManager
    val uri = remember(file) { FileProvider.getUriForFile(ctx, ctx.packageName + ".provider", file) }
    val base = remember(file) {
        Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, mimeOf(file))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    val apps = remember(file) {
        pm.queryIntentActivities(base, 0).sortedBy { it.loadLabel(pm).toString() }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(file.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                if (isTextFile(file)) {
                    item {
                        TextButton(
                            onClick = { onDismiss(); onEdit(file) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("📝  هذا التطبيق (عرض وتعديل النص)", Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
                        }
                    }
                }
                items(apps) { ri ->
                    val icon = remember(ri) {
                        runCatching { ri.loadIcon(pm).toBitmap(96, 96).asImageBitmap() }.getOrNull()
                    }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .combinedClickableSimple {
                                try {
                                    val i = Intent(base).setComponent(
                                        ComponentName(ri.activityInfo.packageName, ri.activityInfo.name)
                                    )
                                    ctx.startActivity(i)
                                    onDismiss()
                                } catch (e: Exception) {
                                    toast(ctx, "تعذر فتح الملف بهذا التطبيق")
                                }
                            }
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (icon != null) Image(icon, null, Modifier.size(40.dp))
                        Spacer(Modifier.width(12.dp))
                        Text(ri.loadLabel(pm).toString())
                    }
                }
                item {
                    TextButton(
                        onClick = {
                            try {
                                ctx.startActivity(Intent.createChooser(base, "فتح باستخدام"))
                                onDismiss()
                            } catch (e: Exception) {
                                toast(ctx, "لا يوجد تطبيق لفتح هذا الملف")
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("قائمة النظام...", Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@OptIn(ExperimentalFoundationApi::class)
fun Modifier.combinedClickableSimple(onClick: () -> Unit): Modifier =
    this.combinedClickable(onClick = onClick)
