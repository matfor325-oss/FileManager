package com.filemanager.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

class MainActivity : ComponentActivity() {

    private var hasAccess by mutableStateOf(false)

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            hasAccess = checkAccess()
        }

    private fun checkAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
        }

    private fun requestAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            permLauncher.launch(
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                )
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hasAccess = checkAccess()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme()) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(Modifier.fillMaxSize()) {
                        if (hasAccess) AppRoot() else PermissionScreen { requestAccess() }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        hasAccess = checkAccess()
    }
}

@Composable
fun PermissionScreen(onRequest: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "يحتاج التطبيق إلى إذن الوصول إلى جميع الملفات ليتمكن من عرضها وإدارتها.",
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = onRequest) { Text("منح الإذن") }
    }
}

@Composable
fun AppRoot() {
    var mode by remember { mutableStateOf<Mode?>(null) }
    var editing by remember { mutableStateOf<File?>(null) }
    val clipboard = remember { mutableStateListOf<File>() }

    Box(Modifier.fillMaxSize()) {
        val m = mode
        if (m == null) {
            HomeScreen { mode = it }
        } else {
            BrowserScreen(
                mode = m,
                clipboard = clipboard,
                onEdit = { editing = it },
                onExit = { mode = null }
            )
        }
        val e = editing
        if (e != null) {
            EditorScreen(e) { editing = null }
        }
    }
}

@Composable
fun HomeScreen(onPick: (Mode) -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Button(
            onClick = { onPick(Mode.MAIN) },
            modifier = Modifier.fillMaxWidth().height(72.dp)
        ) { Text("التخزين الرئيسي", fontSize = 20.sp) }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { onPick(Mode.DOWNLOADS) },
            modifier = Modifier.fillMaxWidth().height(72.dp)
        ) { Text("التحميلات", fontSize = 20.sp) }
    }
}

@Composable
fun EditorScreen(file: File, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val initial = remember(file) { runCatching { file.readText() }.getOrDefault("") }
    var text by remember(file) { mutableStateOf(initial) }
    var saved by remember(file) { mutableStateOf(initial) }
    var askDiscard by remember { mutableStateOf(false) }
    val dirty = text != saved

    fun tryClose() {
        if (dirty) askDiscard = true else onClose()
    }
    BackHandler { tryClose() }

    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = { tryClose() }) { Text("✕") }
                Text(
                    file.name + if (dirty) " *" else "",
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = FontWeight.Bold
                )
                TextButton(onClick = {
                    try {
                        file.writeText(text)
                        saved = text
                        toast(ctx, "تم الحفظ")
                    } catch (e: Exception) {
                        toast(ctx, "تعذر الحفظ")
                    }
                }) { Text("حفظ") }
            }
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.weight(1f).fillMaxWidth().padding(8.dp),
                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 14.sp)
                )
            }
        }
    }

    if (askDiscard) {
        AlertDialog(
            onDismissRequest = { askDiscard = false },
            title = { Text("تغييرات غير محفوظة") },
            text = { Text("هل تريد الخروج دون حفظ؟") },
            confirmButton = {
                TextButton(onClick = { askDiscard = false; onClose() }) { Text("خروج") }
            },
            dismissButton = {
                TextButton(onClick = { askDiscard = false }) { Text("بقاء") }
            }
        )
    }
}
